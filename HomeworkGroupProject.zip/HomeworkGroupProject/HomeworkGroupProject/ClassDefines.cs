﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkGroupProject
{
    static class ClassDefines
    {
        public const int MAX_TELLER_COUNT = 10;
        public const int MSX_CUSTOMER_COUNT = 100;
    }
}
