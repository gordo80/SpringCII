﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkGroupProject
{
    class Transaction
    {
        public Customer OCust;
        public int iTxnAmt;
        public TRANSACTION_TYPE TxnType;
        public int CustID;

        public Transaction()
        {

        }
    
    }
}
